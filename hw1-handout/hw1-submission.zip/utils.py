""" You can define utilities here to be shared across different parts.
"""
